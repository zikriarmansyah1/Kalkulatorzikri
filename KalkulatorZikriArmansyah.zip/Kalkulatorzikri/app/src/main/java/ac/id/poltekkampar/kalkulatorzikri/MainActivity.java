package ac.id.poltekkampar.kalkulatorzikri;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
   private Button satu,dua,tiga,empat,lima,enam,tujuh,delapan,sembilan,nol;
   private TextView TextAngka;
   private Button CLEAR,koma,kali,bagi,tambah,kurang,sama,backspace;

    String Nilai;
    int BIL1, BIL2, jumlah;
    int pilih;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Nilai = "";

        TextAngka = findViewById(R.id.tampilan);

        satu = findViewById(R.id.tombol1);
        dua = findViewById(R.id.tombol2);
        tiga = findViewById(R.id.tombol3);
        empat = findViewById(R.id.tombol4);
        lima = findViewById(R.id.tombol5);
        enam = findViewById(R.id.tombol6);
        tujuh = findViewById(R.id.tombol7);
        delapan = findViewById(R.id.tombol8);
        sembilan = findViewById(R.id.tombol9);
        nol = findViewById(R.id.tombol0);
        koma = findViewById(R.id.koma);
        kali = findViewById(R.id.kali);
        bagi = findViewById(R.id.bagi);
        tambah = findViewById(R.id.tambah);
        kurang = findViewById(R.id.kurang);
        backspace = findViewById(R.id.backspace);
        CLEAR = findViewById(R.id.clear);
        sama = findViewById(R.id.sama);
        initClick();
    }

    public void initClick(){
        satu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Nilai +="1";
                TextAngka.setText(Nilai);

            }
        });
        dua.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Nilai +="2";
                TextAngka.setText(Nilai);

            }
        });
        tiga.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Nilai +="3";
                TextAngka.setText(Nilai);

            }
        });
        empat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Nilai +="4";
                TextAngka.setText(Nilai);

            }
        });
        lima.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Nilai +="5";
                TextAngka.setText(Nilai);

            }
        });
        enam.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Nilai +="6";
                TextAngka.setText(Nilai);

            }
        });
        tujuh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Nilai +="7";
                TextAngka.setText(Nilai);
            }
        });
        delapan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Nilai +="8";
                TextAngka.setText(Nilai);

            }
        });
        sembilan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Nilai +="9";
                TextAngka.setText(Nilai);

            }
        });
        nol.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Nilai +="0";
                TextAngka.setText(Nilai);

            }
        });
        koma.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Nilai +=".";
                TextAngka.setText(Nilai);

            }
        });
        sama.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switch (pilih){
                    case 1:
                        BIL2=Integer.parseInt(Nilai);
                        jumlah = BIL1 * BIL2;
                        Nilai = Integer.toString(jumlah);
                        TextAngka.setText(Nilai);
                        break;
                    case 2:
                        BIL2=Integer.parseInt(Nilai);
                        jumlah = BIL1 / BIL2;
                        Nilai = Integer.toString(jumlah);
                        TextAngka.setText(Nilai);
                        break;
                    case 3:
                        BIL2=Integer.parseInt(Nilai);
                        jumlah = BIL1 + BIL2;
                        Nilai = Integer.toString(jumlah);
                        TextAngka.setText(Nilai);
                        break;
                    case 4:
                        BIL2=Integer.parseInt(Nilai);
                        jumlah = BIL1 - BIL2;
                        Nilai = Integer.toString(jumlah);
                        TextAngka.setText(Nilai);
                        break;
                }

            }
        });
        kali.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BIL1 = Integer.parseInt(Nilai);
                TextAngka.setText("*");
                Nilai="";
                pilih = 1;


            }
        });
        bagi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BIL1 = Integer.parseInt(Nilai);
                TextAngka.setText("/");
                Nilai="";
                pilih = 2;

            }
        });
        tambah.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BIL1 = Integer.parseInt(Nilai);
                TextAngka.setText("+");
                Nilai="";
                pilih = 3;

            }
        });
        kurang.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BIL1 = Integer.parseInt(Nilai);
                TextAngka.setText("-");
                Nilai="";
                pilih = 4;

            }
        });
        backspace.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int length = TextAngka.getText().length();
                int nomor = TextAngka.getText().length() -1;
                String store;

                if (length > 0){
                    StringBuilder Mundur = new StringBuilder(TextAngka.getText());
                    Mundur.deleteCharAt(nomor);
                    store = Mundur.toString();
                    TextAngka.setText(store);
                    Nilai = (store);
                }

            }
        });
        CLEAR.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TextAngka.setText("");
                BIL1 =(int)0.0;
                BIL2 =(int)0.0;
                pilih = (int)0.0;
                Nilai =(String)"";

            }
        });
    }


}